#include <stdio.h>
#include <stdlib.h>

typedef struct
{
	int day;
	int *month;
	int year;
}DOB;

typedef struct
{
	int reg_no;
	char *name;
	char address[30];
}STU_INFO;

typedef struct
{
	char *college_name;
	char university_name[30];
}COLLEGE;

typedef struct
{
	DOB *dob;
	STU_INFO s;
	COLLEGE c;
}STUDENT;

int main()
{
	STUDENT *student;

	student = calloc(1, sizeof(STUDENT));
	student->dob = calloc(1,sizeof(DOB));
	student->dob->month = calloc(1, sizeof(int));
	student->s.name = calloc(30, sizeof(char));
	student->c.college_name = calloc(30, sizeof(char));

	printf("Enter Date of Birth (Day/Month/Year):");
	scanf("%d/%d/%d", &student->dob->day, student->dob->month, &student->dob->year);

	printf("\nEnter Student INFO (Registration Number, Name, Address):\n");
	scanf("%d ", &student->s.reg_no);
	scanf("%[^\n]%*c", student->s.name);
	scanf("%[^\n]%*c", student->s.address);

	printf("\nEnter College INFO (College Name, University Name):\n\n");
	scanf("%[^\n]%*c", student->c.college_name);
	scanf("%[^\n]%*c", student->c.university_name);
	
	printf("\n------------------------------------\n");

	printf("Date of Birth: %d/%d/%d\n\n", student->dob->day, *student->dob->month, student->dob->year);

	printf("Student INFO\nRegistration Number: %d\nName: %s\nAddress: %s\n\n", student->s.reg_no, student->s.name, student->s.address);

	printf("College INFO\nCollege Name: %s\nUniversity Name: %s\n", student->c.college_name, student->c.university_name);

	

}