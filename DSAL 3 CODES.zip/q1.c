#include <stdio.h>

typedef struct
{
	int real;
	int img;
}COMPLEX;

void add(COMPLEX a, COMPLEX b)
{
	printf("\nSum= %d + %di", (a.real+b.real), (a.img+b.img));
}

void multiply(COMPLEX a, COMPLEX b)
{
	 printf("\nProduct= %d + %di",(a.real*b.real - a.img*b.img),(a.real*b.img + a.img*b.real));

}

void substract(COMPLEX a, COMPLEX b)
{
	printf("\nDifference= %d + %di\n", (a.real-b.real), (a.img-b.img));
}

int main()
{
	COMPLEX a,b;
	printf("Enter real part of 1st number:");
	scanf("%d", &a.real);
	printf("Enter imaginary part of 1st number:");
	scanf("%d", &a.img);

	printf("\nEnter real part of 2nd number:");
	scanf("%d", &b.real);
	printf("Enter imaginary part of 2nd number:");
	scanf("%d", &b.img);

	add(a,b);
	multiply(a,b);
	substract(a,b);
}
