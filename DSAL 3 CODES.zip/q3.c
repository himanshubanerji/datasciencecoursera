#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
	int day;
	int month;
	int year;
}DOB;

typedef struct
{
	int hno;
	int zip;
	char state[30];
}ADDRESS;

typedef struct{
	char name[30];
	DOB dob; 
	ADDRESS address;
}EMP;

int main()
{
	int N;
	printf("Enter the number of employees: ");
	scanf("%d", &N);

	EMP *emp;
	emp = calloc(N,sizeof(EMP));

	for(int i = 0; i < N; i++)
	{
		printf("\nEnter Name of employee %d: ", i+1);
		scanf(" %[^\n]%*c", emp[i].name);

		printf("Enter Date of Birth of employee %d: ", i+1);
		scanf("%d/%d/%d", &emp[i].dob.day, &emp[i].dob.month, &emp[i].dob.year);

		printf("Enter Address of employee %d: ", i+1);
		scanf("%d, %d, %[^\n]%*c", &emp[i].address.hno, &emp[i].address.zip, emp[i].address.state);

	}

	printf("---------------------------------------");

	for(int i = 0; i < N; i++)
	{
		printf("\nThe Name of employee: %s ", emp[i].name);

		printf("\nThe Date of Birth of employee: %d/%d/%d", emp[i].dob.day, emp[i].dob.month, emp[i].dob.year);

		printf("\nThe Address of employee: %d, %d, %s", emp[i].address.hno, emp[i].address.zip, emp[i].address.state);

		printf("\n");

	}


}