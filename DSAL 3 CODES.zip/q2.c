#include <stdio.h>
#include <stdlib.h>

typedef struct
{
	char name[30];
	int roll;
	float cgpa;
}STUDENT;

void display(STUDENT s, int i)
{
	printf("Student %d:\tName: %s\tRoll Number: %d\tC.G.P.A: %.2f\t\n", i+1, s.name, s.roll, s.cgpa);

}

void Sort(STUDENT *s, int n)
{
	STUDENT temp;
	for (int i = 0; i < n - 1; i++)
	{

        for (int j = 0; j < n - i - 1; j++)
        {
            if (s[j].roll > s[j+1].roll)
                {
                	temp = s[j];
                	s[j] = s[j+1];
                	s[j + 1] = temp;
                }
		}
	}

}

void read(STUDENT *s, int n)
{
	for(int i = 0; i < n; i++)
	{
		printf("\nEnter Student %d's INFO (Name, Roll Number, C.G.P.A.)\n", i+1);
		scanf("%s", s[i].name);
		scanf("%d", &s[i].roll);
		scanf("%f", &s[i].cgpa);

	}
}

int main()
{

	int n;
	printf("Enter the number of students: ");
	scanf("%d", &n);

	STUDENT *s;
	s = calloc(n,sizeof(STUDENT));

	read(s,n);

	Sort(s,n);
	
	for(int i = 0; i < n; i++)
		display(s[i], i);

	

}